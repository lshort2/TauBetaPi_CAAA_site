AIMS (Audit Information Management System) is table driven and all of
its tables and template schedules and documents are contained in the
SC folder located at C:\Program Files\AIMS\SC.

The SC folder (Template) is maintained and distributed by Audit Services Division.

For more information, suggestions or notification of a problem,
please contact Bob Hatcher, AIMS Coordinator, at 843.852.3600 x 142, 
GroupWise email or hatcher@sctax.org


Template Revision History
=========================

Version 03/15/2003
==================
1. Interest rate increases from 4% to 5% eff 4/1/2004 TM4 and WinPI interest tables are
revised.

2. Item #8 of the 2/4/2004 update has been reversed. Billing details are needed to adjust
receivables.

3. Declaration Table updated for year 2003.

4. End of the audit billing letters 54_PA, 54_APA, 54_Refund, 54_RD-Full and 54_RD-Part
have been revised.

5. Taxpayer information letter for sales audits, 47_TP_info_S, has been revised.

Version 02/04/2003
==================
1. Support is provided for Darlington County School District 1% local option eff 
1-Feb-2004 and Catawba Tribal 6% Sales tax eff 1-Jan-2004 (date when first reported
in the ST-389 local tax worksheet).

2. Support for tax year 2003 is added for individual income tax.

3. Excel template schedule used by foreign corporate auditors is added. Other auditors may
be interesting in the worksheets used to calculate the various ratios.

4. Business Types table is updated from 4-digit SIC to 6-digit NAICS codes. North American 
Industrial Classification System (NAICS) now in use by SCATS Registration eff 02-26-2004.
Complete NAICS manual is available for reference in main menu - HELP.

5. AS-32 Audit Data Sheet revised to support the new NAICS codes.

6. Excel SEATA Nexus schedule is replaced with Word SEATA Nexus document (Rev 11/03).
The new document requires entry of the 6-digit NAICS code.

7. Print only PDF files - CID-6 Appeals, CID-25 Refund & SC-2848 POA are moved to 
main menu - HELP to allow printing without having to copy file into the audit folder.

8. The L-601 Wine return uses the total of Wine Excise and Additional taxes when P&I has
to be computed. Support for this process is now supported (similar to sales and local 
option taxes).

Version 12/10/2003
==================
Fixes AS-1516. Version 19 contains the IIT tax code that was absence from version 18.

Version 12/09/2003
==================
1. Enables checking for updates when TM4 is started.

2. Instructions contained in the AS-1516 form expanded to explain how to select
the individual income tax tab and then TAB to the YEAR field to fill in the
taxpayer's title data into the form. 

Version 12/08/2003
==================
Disables checking for updates when TM4 is started. This is a temporary fix
until a problem in TM4 version 4.0.5.4 is corrected.

Version 12/05/2003
==================
Items 1-2 implement enhancements provided by TM4 ver 4.0.5.4.
---------------------
   *** To change any of these features, use menu SETUP - Reports ***
1. Minimum Font Size for printing has been set as 8, the smallest suggested font size.

2. 3-digit Line numbering is automatically provided to schedules at left & right of 
each line. Line numbers run from 1 to 1000 with 1000 shown as '0' and repeated. This
feature eliminates the need to use column A to contain a row number and provides an
additional column for use when working very wide schedules. Template schedules with
Column A used to contain 'Row #' have been revised by deleting the Row # column.
---------------------
3. Power of Attorney, SC2848.PDF, added to the 'Other Template File' group. To select:
<1> Open T/P folder, <2> Right Click on 'Other Files',<3> Select NEW, 
and <4> Select the file to be added.

4. Holidays table revised to include Christmas Eve, December 24, 2003.

5. P20 - Collection Assessment Fee added to the Explain_Penalty template document.

6. C-179 Penalty Adj Request revised to fit on one page and to right justify the amount
column entries.

7. AS-1516 IIT NOA has been revised to correct a problem when entry is made in line 4b
for lump sum, use and/or additional taxes and how this amount is reflected in the 
AS-54 Billing Report.

Version 11/07/2003
==================
1. Adds the first 'Other Template File' SEATA Nexus.xls.OTF. With TM4 ver 4.0.5.3,
it is now possible to have Excel, Access or Word template files that can be added
to the taxpayer's folder. <1> Open T/P folder, <2> Right Click on 'Other Files',
<3> Select NEW, and <4> Select the file to be added.

2. Revises the TM4 menu - Help by deleting the section for the SEATA Nexus schedule 
as better support is now available.

3. Revises Explain_Sales by correcting the RR- references to AS-.

Version 10/02/2003
==================
Adds to the Tax Rate table, a set of revised Bingo tax codes. They were not included
in 1-Oct update.

Version 10/01/2003
==================
1. Penalty and Penalty Detail schedules used by the F9 Report Generator are revised to
eliminate the formulas in the Specific and Other penalty columns. With TM4 ver 4.0.5.0,
users can not enter a value into a numbric column containing a formula.

2. Adds tax codes for Beer and Wine audits.
BEER  Beer @ 1.00
WINE  Wine Excess @ 1.00
WINA  Wine Additional @ 1.00

3. Adds better support for Regulatory Division Bingo audits.
a. Tax codes
BEXP  Bingo Excess Proceeds @ 1.00
BPCW  Catawba Bingo Paper @ 0.10
BPPF  Bingo Paper (F) @ 0.05
BPPR  Bingo Paper @ 0.165

b. Bingo 'District' added for Setup-District default setting. It changes Division name
in schedules, documents and reports from Audit Services to Regulatory.

c. Template schedules
Bingo-01 for Excess Proceeds
Bingo-02 for Bingo paper using BPPR tax code. Change tax code for other types of paper.
Bingo-03 for assessed penalties
Bingo-04 for Bingo Tax of $0.01 needed for TM4 to generate a Billing Report when all of
the audit findings result in just penalty assessment.

d. Bingo appointment letter and Extract of chapter 24.

Version 09/19/2003
==================
1. Interest Rate changed from 5% to 4% effective 10/1/2003.
TM4 and WinPI interest table updated.

2. Win-PI update to version 2.06 is distributed to correct minor printing problems.

3. Adds SCDOR Help article 10.1 discussing lessons learned during the Dell 2003 Rollout.

Version 09/08/2003
==================
1. Prefix of most FS and RR forms changed to AS for Audit Services.

2. Solid Waste (SWAMP) tax rate for tire disposal (TIRED) of -1.00 added to
go along with the rate for tire sales (TIRES) of 1.94.

3. To parallel the ST-390 Solid Waste Tax return, P&I is computed on the total of the
taxes for tires, oil, batteries and white goods. This is same treatment given to the
local option taxes.

4. TM4 ver 4.0.5.0 and AS-1516 ver 17 (9/03) revised. Results of all reports and forms are
in agreement. AS-1516 calculated tax matches paper tax table.

Version 04/16/2003
==================
1. Support added for Hampton County Capital Projects Local Option eff 05/01/2003.

2. SCDOR TM4 Help revised.
a.  Chapter 7 for Computer Assisted Audit System revised.
b.  Chapter 8 for SEATA added.

3. MS Word document TM4 SCDOR Help Manual provided.

4. Individual Income tax tables for 1993, 94 & 95 enhanced to match paper tax table.

5. Letters revised due to Division Name change.

6. Charleston Transportation tax @ 1/2%, scheduled to be implemented 5/1/2003, has been
held in abeyance by SC Supreme Court pending results of hearing.

7. ST-10R revised to support the ST-10 (rev 6/4/02).

8. Declaration Table used for IIT 2210 penalty updated.

Version 12/20/2002
==================
1. Interest Rate changed from 6% to 5% effective 1/1/2003.
TM4 and WinPI interest table updated.

2. Charleston Transportation Tax @ 1/2 cent and Dillon Capital Project Tax @ 1%
become effective 5/1/2003. Tax Rate and Tax Lookup tables revised. Explain_Sales
updated.

3. IIT table for years 1996 thru 1998 revised to agree with the paper tax table.
With this update, exact tax results for 1996 thru 2002 (most current 7 years) are
in place. Earlier years will be revised by March 2003.

4. MS Excel schedule "SEATA Nexus.XLS" is added for use in SEATA reporting.

Version 11/27/2002
==================
1. Revised, Template document Label1 to provide a label for the T/P Audit
Survey form.

2. Revised, IIT Table for years 1999 thru 2002 to agree with paper tax table.
1996 thru 1998 will be the next update. Earlier years to follow.

3. SCDOR Help (Article #)
a. Added, Policy - File & Folder Name Conventions (4.5).
b. Revised, How To - IIT - Filing Detail - Penalties - Substantial Understatement (2.3.5) 
to include requirement for return to have been filed.
c. Revised, How To - IIT - Tax Calculations (2.3.9) as required by item 2 above.

4. Tax Rate table
a. Revised, Jasper County from Capital Project to School District. Audits completed in 
Nov-2002 will use the Capital Project G/L code. Those completed after this update will 
use the School District G/L code.
b. Added, Tax Rates BPPR for Bingo Paper and BPCW for Catawba Bingo Paper.

5. Revised date format of the F9 set of reports from mm/yy to mm/dd/yyyy. Change provides 
better support for audits of 28-Day and 4/4/5 Week Reporters and Bingo paper audits.

Version 11/08/2002
==================
1. Template document 54_RD-Part reissued.

2. sCDOR Help manual
a. The format has been revised to include for each article the chapter and 
article number at the top right. For those who print this manual, article 
by article to create a reference document, this change will make it easier to 
find the desired article.

b. Articles 2.3.3 Tax Tab, 2.3.5 Filing Detail - Penalties, 5.3 Audit Control 
Number, 7.5 Returns Being Audited, and 7.8 Amnesty Audits - All Periods Eligible
have been revised.

c. Articles 7.14 General Comments, 7.15 Refund Periods and 7.16 Lessons
Learned have been added.

Version 10/30/2002
==================
1. Town of James Island within Charleston County is assigned the 
Municipality Code of 2441. However the ZIP Code of 29412 for James Island
has sections within City of Charleston, Unincorporated - County of
Charleston and Town of James Island. Tax Rate and Tax Code Lookup tables have
been revised to reflect this addition.

2. Closing section in all Appointment and end of audit letters and the
Field Amnesty letter revised from 13 to 8 lines

3. Rights (Bill of Rights) edited to correct telephone area code.

4. Holiday table revised to include Christmas Eve, 12/24/2002.

5. SCDOR Help
a. Revised - articles 2.3.3 Tax Tab, 2.6.3 Fiscal Year Filers, 5.3 Audit Control
Number, and Amnesty Chapter 7.2 General, 7.9 Placement of Documents in Audit Folder,
7.10 Amnesty Audits - Old & New Periods/Tax Tabs and 7.12 Amnesty Audits - District
Reporting.

b. New - Amnesty article 7.13 CID Periods

Version 09/25/2002
==================
All changes in support of Tax Amnesty
1. Deleted template document 'C179A'. It is not needed.

2. Added Template schedule 'Report' to capture and report net P&I
difference for amnesty periods.

3. Revised SCDOR Help accordingly.
a. Articles 7.02, 7.08 and 7.09 to remove references to the 'C179A'.
b. Articles 7.08, 7.09 and 7.12 to document the 'Report' schedule.

Version 09/11/2002
==================
All changes in support of Tax Amnesty
1. Template documents C176A and C286A revised. Name of 'Tax Code' column
changed to 'Tax Type' to agree with Billing Summary.

2. Field Audit Amnesty Letter added.

3. SCDOR Help Updated
a. Articles 6.5.2 and 6.5.3 to include above forms and letter.
b. Amnesty, Chapter 7, expanded and revised.


Version 08/28/2002
==================
1. Amnesty
a. Template document C286A revised. G/L column deleted.
b. Template document C176A issued.
c. SCDOR Help Chapter 7 for Amnesty added.

2. Holiday Table updated for year 2003.

3. RR-1516 (Ver 12 8/02) revised to pull data from the tax tab. 
Spouse's SS# is pulled from the field AUDIT1. SCDOR Help articles
2.3.2, 2.3.3 and 2.3.6 have been updated.

4. Template document 54_NC revised to correct a spelling error.


Version 08/16/2002
==================
1. Template document C286A Tax Reprieve-Amnesty Taxpayer Application
for Notice of Assessment distributed.

2. Template document FS45 Disputed Issue Report revised to correct
the Audit Control Number field.

3. Template documents FS45, 32_A_Data, and FS43 revised to show Audit 
Manager instead of Audit Supervisor. FS43 also revised to insert the
tax name in paragraph (1) such as "... STATE 'Sales Tax' due on ...". 

4. Template table Audit Types revised to include the tax Activity
Code. Future program enhancement will enter this data into the Tax Tab
when the Tax Type is selected. Intent is to have activity code available
for automatic fill into the R-32 Audit Data Sheet. Table sorted by tax
name in alphabetic order.

5. Filing detail schedule column for Substantial Understatement formula
revised so it will not assess this penalty when assessed tax is 5000 or
less. Auditor will have to edit this formula to 10000 when taxpayer is
a corporation. Read SCDOR Help 2.3.4 for details.

6. SCDOR Help updated
a. 2.3.4 Filing Detail - Penalties  [revised]
b. 3.7 Local Option Taxes  [new]  

Version 07/31/2002
==================
1. Title change of audit supervisor to audit manager made to SCDOR
Help, to template documents and to District INI files.

2. SCDOR Help revised/expanded.
a. Table of Content now linked to articles.
b. Audit Services Organizational Chart added.
c. Payment Processing Considerations - Negligence and Civil Fraud
updates stop when tax balance is zero. This conforms to mainframe.
d. Computer Assisted Audit System article added.
e. How To article added for Unlicensed Retailer - Retail License Tax.

3. Explain_Sales template document
a. S12 Food Tax revised.
b. S13 Retail License Tax added.
c. S14 Failure to pay license tax added.

Version 07/15/2002
==================
1. Tax code contained in the Retail License template schedule has been 
corrected.

2. E_Mail Authorization template document has been added. It is 
used to obtain authorization by taxpayer for SCDOR to e-mail tax 
information to them.

3. SCDOR Help expanded to include a Chapter for Audit Workpapers Manual.

Version 06/13/2002
==================
1. SCDOR Help distributed. It includes, in part, all of the 
information previously contained in 'Instructions for IIT Audits', 
'How_To', and 'Policy for Local Unknown 9999' documents. These documents 
have been deleted as separate files.

2. Template schedules 'Retail License', 'Corporate Income' and
'Corporate License' have been added.

3. 'Audit Types' table has been expanded to include 'Retail License Tax'.

4. State and CID INI files have been revised.

Version 04/09/2002
==================
1. All letters have been revised to insert a 'Long date Placeholder" 
at the top left of the documents to correct an omission made in the
earlier update.

2. The template document 54_RD-Part has been modified to inform 
taxpayer his reduced refund processing time can be reduced by
signing the SC 870 Waiver of Restriction on Assessment.

Version 04/08/2002
==================
1. Division title changed from "Revenue and Regulatory Operations" to
"Law & Compliance". In the closing section of all letters, the phrase
"Audit Services" has been inserted below the name and title and above 
the telephone number.

2. The form "Taxpayer - Audit Quality Survey" has been added as a 
template document.

3. Template document "Instructions for IIT Audits" revised to stress
the need to close all Forms before doing the F9 Report Generator and
afterwards to open and print each Form. This ensures results of 
penalty and interest are the same in the printed Billing and in the 
NOA RR-1516 for each year included in the audit.

4. Explain_Sales modified to correct a typing error.

5. The first edition of out AT&T Electronic Auditors' News has been 
added as the Word document e-AuditN.doc into the SC folder to
facilitate its use as a reference document. The plan is to later 
include it as a chapter in the SC electronic help manual designed 
to complement the TM4 electronic help manual.

Version 03/21/2002
==================
1. Win-PI files (PI.exe & INT.txt) added to provide support to those 
who connect using Remote/VPN Access. All TM4 users should create 
shortcut to PI.exe found in C:\Program Files\AIMS\SC and then delete 
the older Win-PI icon. When this program is revised or when our 
interest rate is changed, the changes will be distributed within the 
SC Folder update.

2. The Audit Types Table was revised to correct return date for
corporate license fee. Filing detail schedule for open audits must be
rebuilt to generate the correct return due date for this tax.

Version 03/04/2002
==================
Template document CAA-40 Elec Data Transmittal added.

Version 02/07/2002
==================
1. RR-1516 IIT Form (Rev 10) revised to show the mid-point used for
tax calculations. The mid-point amount is also shown as taxable 
measure in the F9 R/G Billing Report. Change permits tax, interest 
and penalty amounts to be same in RR-1516 forms and in the 
R/G Billing Report.
Mid-point of ranges determined as shown below
_ $   0 - $  19.99: 0  [Taxable floor has been $20 since 1992]
_ $  20 - $6999.99: Nearest $25 or $75
_ $7000 and over  : Nearest $50.

2. Template document "Instructions for IIT Audits" revised.

3. Tax Rate table tax rates for CIGRT corrected. Rates for the two
periods had been reversed.

4. Bingo Excess Proceeds template schedule added.

5. Tax Code Lookup table revised to show full name of County when
city is in two or more Counties.

Version 02/01/2002
==================
1. Version 9 of the RR-1516 IIT Notice of Adjustment has been revised
to compute tax using the mid-point of the range containing the tax 
measure. For measures under 7,000, a $50 range is used and the 
mid-points are 25 and 75. For measures at and above 7,000, a $100 
range is used and the mid-point is $50. TM4 rounds all tax results to
the second decimal place. This feature can not be changed to support 
how the main frame rounds this tax to the dollar.

2. Template document "Instructions for IIT Audits" revised.

3. The following template files have been deleted.
a. Individual Income Tax.STF
b. Sales FS-36-1.STF
c. SCDOR400.BMP

4. A copy of Portia Richardson's letter of March 15, 2001, containing
our Policy for Local Option procedures when the appropriate local
city/county code can not be determined is provided as "Policy for Local 
Unknown 9999."

5. Support for Cigarette/Tobacco and Bingo Excess Proceeds taxes added.
a. Audit Types Table revised - Business License due date changed to
20th of the following month.
b. Tax Rate Table expanded -
CIGRT - Cigarette Tax
BEXP  - Bingo Excess Proceeds Tax
OTOBP - Other Tobacco Products Tax

Version 01/14/2002
==================
1. New Appoint_Ltr_CAA and revisions to 32_A_Data and 47_TP_Info_S
template documents to provide better support for our Computer Assisted
Audits.

2. IIT Table revised to include support for CY 1987 and 1988. We now 
have automatic support for 1987 thru 2002 - a total of 16 years.

3. IIT Table constants have been revised slightly to reduce the
difference between the paper tax charts and the tax computed using the
mid-range measure.

4. Interest Table revised to separate the first interest period of 
09/01/85 to 12/31/85 into two quarters of 09/01/85 to 09/30/85 and
10/01/85 - 12/31/85.

Version 12/06/2001
==================
1. Rights document revised. References to Closed Districts deleted
from the last page.

2.IIT Table revised to include new tax tables for CY 2001 and 2002. 

3. Interest Table revised to include 6% interest rate 
effective 1-Jan-2002.

Version 11/13/2001
==================
1. Changes for District Office Realignments. This completes the changes
to TM4 SC Folder required to support the downsizing from 9 to 4 
Districts offices, personnel reassignments and retirements.
_ AIKEN.INI deleted.  District office closed.
_ SPARTANBURG.INI deleted. District office closed.
_ FLORENCE2.INI deleted. Doug Driggers retired.
_ COLUMBIA2.INI added for Will Barnes.

2. Holiday Table revised to include Monday, Dec 24, 2001, as a State
holiday.

3. Penalty.ATF revised to preclude entry of a negative penalty. 
Read-Only property of columns A and B removed.

4. Tax Code Lookup table revised to display all municipalities. Tax 
Codes for those that are not subject to 'regular' or special local 
option taxes will be "N/A". When such a location is selected, its NAME 
and the tax code "N/A" will be inserted into your schedule.

5. Based upon several requests, a "BLANK" schedule [Columns for Date,
Description and Amount] has been added as a template.

6. Audit Data Sheet, 32_A_Data, revised to increase space for the 
auditor signature(s) from 1 to 3 lines.

7. Tax Code CIB for "Catawba Indian Bingo Tax" added to Tax Rate table.

8. Template document "Apparent Failure to File IIT Ltr" added. This is
the last document to be added from the Lotus Audit Template program.

Version 10/14/2001
==================
Items 1, 2 and 3 revised as suggested during TM4 training at Rock Hill.
1. Tax Rates table updated
Tax rates for 85-F (individuals 85 and older - Food) corrected.

2. Appointment letters revised to use table for listing items.

3. RR-56 Chronological Report - table column alignment changed.

4. Changes for District Office Realignments
_ Myrtlebeach.INI file deleted. District office Closed.

Version 10/08/2001
==================
1. Tax Rates table updated
G/L Code for Withholding corrected.
SOFTD - Soft drink tax records added.

2. Audit Routing Sheet template document added.

3. Changes for District Office Realignments
_ Greenville1.ini file deleted. Ed Poore retired.
_ Beaufort.INI file deleted. District office closed.
_ Charleston2.INI file added for Buddy Creech.


Version 09/21/2001
==================
1.'Instructions for individual income tax' expanded to include 
information provided in various emails.

2. 'C-179 - Penalty Adjustment Request/Notification' field for Audit
Control Number was fixed.

3. Template documents distributed.
ST10R - Application for Certificate Report
Fax Cover Sheet                              [utility]
RR-56 Chronological Report                   [optional]
Index of Audit Papers                        [optional]
RR-82 - Receipt for Records

Version 09/05/2001
==================
Template document 'Instructions for individual income tax' revised to
indicate where to record the FILE # assigned to the last return 
included in the audit and to use the field "Audit1" to record the 
wife's SS # when returns are filed as married jointly filing.

Version 08/31/2001
==================
1. Template documents distributed.
FS78 - Notification of sampling procedures
FS90 - Computer assisted audit questionnaire
STARS Form 92A - Miscellaneous Expense Support Document
ST-10R - Application for Certificate Report[not ready, issued in error]

2. TM4 How_To series started. Documents in this series are contained in
template document How_To

3. Spelling error in title line of 'FS-36 Individual Income' corrected.

4. 32_A_Data - New field added for Average Hours per location
(Total Hours / # Locations). Entry required when multiple locations
are audited. 

Version 08/17/2001
==================
1. Template documents distributed.
C100 - Special Report
C120 - Office Memorandum
C245 - Protest
FS33 - Power of Attorney
FS45 - Disputed Issues
FS55 - Conference Report
FS6  - Customer Authorization

2. Location of SC Readme text and TM4 Logo changed from Drive D to C.
Had to wait for last District to be 'refreshed.'


Version 08/03/2001
==================
Template documents distributed. Slight change in style/format.
Others will be reissued at a later date to conform.
C179 & C179-Reverse - Penalty Adjustment Request/Notification
FS43 - Consent to Extend the Time to Assess Tax
FS93 - 2nd Consent to Extend the Time to Assess Tax 
RR-54-ADJ - Column for Cost added.
SC870 & SC870-Reverse - Waiver/Consent to Assessment & Collection
32_A_Data - Contact person's Title added

Version 06/29/2001
==================
Tax Table - Food Tax rate of 4% ends 06/30/2001.

The TM4 'FOOD' tax code and its G/L Code 14-3714 are limited to use for
the period 1 January to 30 June 2001. Entries dated afterwards for 
'FOOD' will be taxed at a rate of ZERO percent since there is no G/L
Code for this tax for dates after 06/30/2001.

Version 06/24/2001
==================
1. Interest table updated for 7% interest effective 1-Jul-2001.

2. Business Type SIC table updated to include 13 new activity codes.

3. Closing of the appointment and the 54_ series End of Audit letters 
revised. 

Version 06/10/2001
==================
1. Template schedules FS-36 Individual Income, Gasoline and Special Fuel
added. FS-36 Individual Income schedule title now set for Yr 2000. You
must edit the year '2000' when schedule is used for other years.

2. Extra spacing added to reports to allow their use as a processing
document. Savings in processing effort more than offset extra cost for
paper and ink. 

3. Option to view text of the SC folder ReadMe is added to Help menu.
Option to view text of TM4 ReadMe is available in Setup - Update.

4. A template document containing instructions for individual income
audits provided as 'Instructions for IIT'.

5. BT-10 and Rights have been converted into a TM4 template document.

Version 05/18/2001
==================
1. Rev 8 RR-1516. Adds fields for entry of the number of exemptions
under age 6 and age 65 and older. These fields are contained in the
Year 2000 SC1040 return. Also corrects spelling errors.

2. Filing Detail enhanced to include substantial understatement penalty.
Auditor must check when appropriate.

3. Template documents in the 54_series, such as 54_APA, corrected to
use longdate placeholder.

4. Tax Code Lookup table for Chesterfield School LO code corrected
from 1013S to 5131S

5. IIT.tab distributed 3-Apr-2001, reissued. It had been over-written,
in error, by the 29-Apr-2001 release.

Version 05/01/2001
==================
Revision 7 of the RR-1516 form, IIT NOA distributed to provide
correct totals of tax, interest and penalty to the F9 Reports.
Previous revisions understated audit interest and penalty by amounts
of interest and penalty paid with return/extension/prior NOAs and 
understated line 12 Total Amount Due (Refund) by the same amounts.

Version 04/29/2001
==================
1. Appointment letters corrected to use longdate placeholder so that
the current date is placed at the top of the letters.

2. Columbia District relocation to the main office has been completed.
File containing addresses and telephone numbers has been updated.

3. IIT Notice of Adjustment, RR-1516, Revision 5 released.
a. All lines and/or fields are numbered.
b. Filing Status # added.
c. 10d check box permits manual calculation of declaration penalty.
d. Audit adjustments of tax, penalty and interest are clearly shown in
9b, 10g and 11c.

Version 04/15/2001
==================
IIT Notice of Adjustment, RR-1516, revised to include <1> payment with 
return and prior NOA details of tax, interest and penalty, <2> similar
break-outs for lines 10 (penalty) and 11 (interest), <3> 2-line Comment
section, and <4> Adjustment summary box at bottom right of audit tax, 
interest and penalty.

Version 04/03/2001
==================
1. IIT.TAB updated to include Year 2000 individual income variable tax
rate table. This tab allows TM4 to duplicate SCATS IIT tax 
calculations as used in the IIT NOA by Office Audit.

2. For situations when the LO delivery site is, indeed, unknown, the 
LO Code " 9999 - Unknown delivery site " has been added to the tax 
rates and to the tax lookup tables. Please refer to Portia Richardson's
memo of 15-Mar-2001 for applicable procedures. A copy has been provided
to Audit Supervisors.

3. Improved support for individual income tax. RR-1516.TMF 
[TaxMaster Form] added. It uses the 'short cut %' Declaration Penalty.

4. Audit folder can now have schedules, documents and forms. 
The RR-1516 is the first form to be provided.

Version 03/21/2001
==================
Penalty schedule used to create the Filing Detail schedule expanded
to include a column for OTHER penalties. Auditor to enter total
amount of all other penalties assessed for the period. This provides
a needed flexibility and the ability to work all taxes.

Version 03/14/2001
==================
1. RR-54-ADJ document distributed for use in audit containing
pre-payments, installment payments, or warrants.

2. Interest table updated to include 8% effective 1-Apr-2001.

3. The first paragraph of the appointment letters has been revised


Version 03/01/2001
==================
First SC folder update obtained from FTP DragNet site.
1. Logo revised to correct spelling error.

2. 'FS' title changed to 'RR' in all documents and schedules.

3. RR-54 form number added to Billing.

4. Explain_Sales
4.1 S09: Local Option updated.
4.2 S11: S&U 4% for 85 and Older added.
4.3 S12: Food Tax at 4% added.
4.4 'RR-36-xx' titles returned to Adjustment explanations.

5. Explain_Penalty
5.1 P04: Failure to File (More than 60 days) updated.
5.2 Section containing instructions in how to use the 3 Failure to
File columns found in the Filing Detail schedule added above P03.
5.3 Code cites updated.

6. Expanded numeric format width to 17 in schedules used by TM4 when
reports are generated. This change should eliminate the #########
displayed when large numbers are being processed in an audit.

7. County names, such as Charleston County and Beaufort County, added
to the Local Option Lookup

Note
=====
Earlier revisions were not identified by version date when they were
distributed.
